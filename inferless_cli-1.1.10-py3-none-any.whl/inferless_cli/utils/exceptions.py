class ModelImportException(Exception):
    pass

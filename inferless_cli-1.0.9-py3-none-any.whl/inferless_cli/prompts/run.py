import os
import rich
from ruamel import yaml
from inferless_cli.utils.constants import (
    DEFAULT_RUNTIME_FILE_NAME,
    DEFAULT_YAML_FILE_NAME,
)
from inferless_cli.utils.helpers import (
    build_docker_image,
    copy_to_container,
    create_config_from_json,
    create_docker_file,
    is_docker_running,
    is_inferless_yaml_present,
    read_yaml,
    start_docker_container,
    yaml,
)


def local_run():
    is_yaml_present = is_inferless_yaml_present(DEFAULT_YAML_FILE_NAME)
    if is_yaml_present:
        config = read_yaml(DEFAULT_YAML_FILE_NAME)
        if not is_docker_running():
            rich.print("[red]Docker is not running.[/red]")
            return
        model_name = config["name"]
        create_config_from_json(config)
        yaml_location = DEFAULT_RUNTIME_FILE_NAME

        sys_packages_string = None
        pip_packages_string = None
        api_text = f"""
FROM nvcr.io/nvidia/tritonserver:23.06-py3

RUN apt update && apt -y install libssl-dev tesseract-ocr libtesseract-dev ffmpeg

RUN pip install --upgrade pip

##oslibraries##

COPY requirements.txt requirements.txt

RUN pip install  --no-cache-dir  -r requirements.txt

##piplibraries##

COPY . /model/{model_name}/1/

COPY config.pbtxt /model/{model_name}
            """
        if os.path.exists(yaml_location):
            with open(yaml_location, "r") as yaml_file:
                yaml_dict = yaml.load(yaml_file)
                sys_packages_string = ""
                pip_packages_string = ""
                if (
                    "system_packages" in yaml_dict["build"]
                    and yaml_dict["build"]["system_packages"] is not None
                ):
                    sys_packages_string = "RUN apt update && apt -y install "
                    for each in yaml_dict["build"]["system_packages"]:
                        sys_packages_string = sys_packages_string + each + " "
                if (
                    "python_packages" in yaml_dict["build"]
                    and yaml_dict["build"]["python_packages"] is not None
                ):
                    pip_packages_string = "RUN pip install "
                    for each in yaml_dict["build"]["python_packages"]:
                        pip_packages_string = pip_packages_string + each + " "

                api_text = api_text.replace("##oslibraries##", sys_packages_string)
                api_text = api_text.replace("##piplibraries##", pip_packages_string)

        # Create Dockerfile from API text
        create_docker_file(api_text)

        # Build Docker image
        build_docker_image()

        # Start Docker container
        start_docker_container()

        # Copy current directory to container
        copy_to_container(model_name)

        rich.print("Container started successfully.")

import time
import os
import subprocess
import rich
from ruamel import yaml

from inferless_cli.utils.constants import (
    DEFAULT_RUNTIME_FILE_NAME,
    DEFAULT_YAML_FILE_NAME,
)
from inferless_cli.utils.helpers import (
    build_docker_image,
    copy_to_container,
    create_config_from_json,
    create_docker_file,
    decrypt_tokens,
    generate_template_model,
    is_docker_running,
    is_inferless_yaml_present,
    read_yaml,
    start_docker_container,
    stop_containers_using_port_8000,
    yaml,
)
from inferless_cli.utils.services import get_volume_info_with_id


def local_run():
    _, _, _, workspace_id, _ = decrypt_tokens()
    is_yaml_present = is_inferless_yaml_present(DEFAULT_YAML_FILE_NAME)
    volume_path = None
    if is_yaml_present:
        config = read_yaml(DEFAULT_YAML_FILE_NAME)
        if (
            config
            and "configuration" in config
            and "custom_volume_id" in config["configuration"]
        ):
            volume_data = find_volume_by_id(
                workspace_id, config["configuration"]["custom_volume_id"]
            )
            volume_path = volume_data["path"]
            print(volume_data["path"])
        if not is_docker_running():
            rich.print("[red]Docker is not running.[/red]")
            return
        model_name = config["name"]
        inputs = create_config_from_json(config)
        generate_template_model(config)
        yaml_location = DEFAULT_RUNTIME_FILE_NAME

        sys_packages_string = None
        pip_packages_string = None
        api_text = f"""
FROM nvcr.io/nvidia/tritonserver:23.06-py3

RUN apt update && apt -y install libssl-dev tesseract-ocr libtesseract-dev ffmpeg

RUN pip install --upgrade pip

##oslibraries##

COPY requirements.txt requirements.txt

RUN pip install  --no-cache-dir  -r requirements.txt

##piplibraries##

COPY . /models/{model_name}/1/

COPY config.pbtxt /models/{model_name}
            """
        if os.path.exists(yaml_location):
            with open(yaml_location, "r") as yaml_file:
                yaml_dict = yaml.load(yaml_file)
                sys_packages_string = ""
                pip_packages_string = ""
                if (
                    "system_packages" in yaml_dict["build"]
                    and yaml_dict["build"]["system_packages"] is not None
                ):
                    sys_packages_string = "RUN apt update && apt -y install "
                    for each in yaml_dict["build"]["system_packages"]:
                        sys_packages_string = sys_packages_string + each + " "
                if (
                    "python_packages" in yaml_dict["build"]
                    and yaml_dict["build"]["python_packages"] is not None
                ):
                    pip_packages_string = "RUN pip install "
                    for each in yaml_dict["build"]["python_packages"]:
                        pip_packages_string = pip_packages_string + each + " "

                api_text = api_text.replace("##oslibraries##", sys_packages_string)
                api_text = api_text.replace("##piplibraries##", pip_packages_string)

        # Create Dockerfile from API text
        create_docker_file(api_text)

        # Build Docker image
        build_docker_image()

        # Start Docker container
        stop_containers_using_port_8000()
        start_docker_container(volume_path=volume_path)
        rich.print("[green]Container started successfully.[/green]\n")
        # Copy current directory to container
        time.sleep(15)
        execute_curl(
            [
                "curl",
                "--location",
                "--request",
                "POST",
                f"http://localhost:8000/v2/repository/models/{model_name}/load",
                "--header",
                "Content-Type: application/json",
            ]
        )
        curl_command = print_curl_command(model_name, inputs)

        execute_curl(curl_command)

        rich.print("[green]Model load successfull.[/green]\n")

        rich.print("Container started successfully.")


def execute_curl(curl_command):
    subprocess.run(curl_command, shell=True)


def find_volume_by_id(workspace_id, volume_id):
    volume = get_volume_info_with_id(workspace_id, volume_id)

    return volume


def print_curl_command(model_name: str, inputs: dict):
    curl_command = f"curl --location 'http://localhost:8000/v2/models/{model_name}/infer' --header 'Content-Type: application/json' --data '{inputs}'"
    print(f"[bold]Curl Command:[/bold]\n{curl_command}")
    return curl_command

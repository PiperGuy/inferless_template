import os
import rich
from ruamel import yaml
from inferless_cli.utils.constants import (
    DEFAULT_RUNTIME_FILE_NAME,
    DEFAULT_YAML_FILE_NAME,
)
from inferless_cli.utils.helpers import (
    build_docker_image,
    copy_to_container,
    create_docker_file,
    is_docker_running,
    is_inferless_yaml_present,
    read_yaml,
    start_docker_container,
)


def local_run():
    is_yaml_present = is_inferless_yaml_present(DEFAULT_YAML_FILE_NAME)
    if is_yaml_present:
        config = read_yaml(DEFAULT_YAML_FILE_NAME)
        if not is_docker_running():
            rich.print("[red]Docker is not running.[/red]")
            return

        yaml_location = DEFAULT_RUNTIME_FILE_NAME

        sys_packages_string = None
        pip_packages_string = None
        api_text = """
        FROM nvcr.io/nvidia/tritonserver:23.06-py3

        RUN apt update && apt -y install libssl-dev tesseract-ocr libtesseract-dev ffmpeg

        RUN pip install --upgrade pip

        ##oslibraries##

        COPY requirements.txt requirements.txt

        RUN pip install  --no-cache-dir  -r requirements.txt

        ##piplibraries##
            """
        if os.path.exists(yaml_location):
            with open(yaml_location) as f:
                yaml_dict = yaml.load(f)
                sys_packages_string = ""
                pip_packages_string = ""
                if (
                    "system_packages" in yaml_dict["build"]
                    and yaml_dict["build"]["system_packages"] is not None
                ):
                    sys_packages_string = "RUN apt update && apt -y install "
                    for each in yaml_dict["build"]["system_packages"]:
                        sys_packages_string = sys_packages_string + each + " "
                if (
                    "python_packages" in yaml_dict["build"]
                    and yaml_dict["build"]["python_packages"] is not None
                ):
                    pip_packages_string = "RUN pip install "
                    for each in yaml_dict["build"]["python_packages"]:
                        pip_packages_string = pip_packages_string + each + " "

                api_text = api_text.replace("##oslibraries##", sys_packages_string)
                api_text = api_text.replace("##piplibraries##", pip_packages_string)

        # Create Dockerfile from API text
        create_docker_file(api_text)

        # Build Docker image
        build_docker_image()

        # Start Docker container
        start_docker_container()

        # Copy current directory to container
        copy_to_container(config["name"])

        rich.print("Container started successfully.")

import os
import base64
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

try:
    import keyring
except ImportError:
    keyring = None

INFERLESS_DIR = os.path.join(os.path.expanduser("~"), ".inferless")
CREDENTIALS_FILE = os.path.join(INFERLESS_DIR, ".credentials")

if not os.path.exists(INFERLESS_DIR):
    try:
        os.makedirs(INFERLESS_DIR)
    except OSError as e:
        print("Error creating directory:", e)

# Check if file exists, if not, create it
if not os.path.exists(CREDENTIALS_FILE):
    try:
        open(CREDENTIALS_FILE, "a").close()
    except OSError as e:
        print("Error creating file:", e)

# Check if file was created
if os.path.exists(CREDENTIALS_FILE):
    print("File created successfully:", CREDENTIALS_FILE)
else:
    print("File creation failed:", CREDENTIALS_FILE)

# Define a salt and a key derivation function
SALT = b"\xc6\x9a\xf8\xc9\xa9\x1d\xd3\x93\xc8\xf9\x8a\x8a\xd2\xf1\xec\xc8"

INFERLESS_KEY = "SkBya_fdKRnTPSCIKbgrQNOxD8Dp86Csxnhn1hTkS3Y="

KEYRING = keyring


# Define a function to load the encryption key from an environment variable
def load_key():
    key = INFERLESS_KEY
    if key is None:
        raise ValueError("INFERLESS_KEY environment variable not set")
    return base64.urlsafe_b64decode(key)


# Define a function to encrypt and save the credentials
def save_credentials(
    access_key,
    access_secret,
    token,
    refresh_token,
    user_id,
    workspace_id,
    workspace_name,
    mode,
):
    try:
        # Load the existing credentials
        (
            existing_access_key,
            existing_access_secret,
            existing_token,
            existing_refresh_token,
            existing_user_id,
            existing_workspace_id,
            existing_workspace_name,
            existing_mode,
        ) = load_credentials()

        # Use the new values if provided, otherwise retain the existing values
        access_key = access_key if access_key else existing_access_key
        access_secret = access_secret if access_secret else existing_access_secret
        token = token if token else existing_token
        refresh_token = refresh_token if refresh_token else existing_refresh_token
        user_id = user_id if user_id else existing_user_id
        workspace_id = workspace_id if workspace_id else existing_workspace_id
        workspace_name = workspace_name if workspace_name else existing_workspace_name
        mode = mode if mode else existing_mode

        # Create the .inferless directory if it doesn't exist
        os.makedirs(INFERLESS_DIR, exist_ok=True)

        # Load the encryption key
        key = load_key()

        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=SALT,
            iterations=100000,
        )

        # Create a Fernet object with the encryption key
        fernet = Fernet(base64.urlsafe_b64encode(kdf.derive(key)))

        # Encrypt the credentials
        encrypted_access_key = (
            fernet.encrypt(access_key.encode()) if access_key else b""
        )
        encrypted_access_secret = (
            fernet.encrypt(access_secret.encode()) if access_secret else b""
        )
        encrypted_token = fernet.encrypt(token.encode()) if token else b""
        encrypted_refresh_token = (
            fernet.encrypt(refresh_token.encode()) if refresh_token else b""
        )
        encrypted_user_id = fernet.encrypt(user_id.encode()) if user_id else b""
        encrypted_workspace_id = (
            fernet.encrypt(workspace_id.encode()) if workspace_id else b""
        )
        encrypted_workspace_name = (
            fernet.encrypt(workspace_name.encode()) if workspace_name else b""
        )
        encrypted_mode = fernet.encrypt(mode.encode()) if mode else b""
        # Write the encrypted credentials to the .credentials file
        print("Pathexists:", os.path.exists(CREDENTIALS_FILE))
        with open(CREDENTIALS_FILE, "wb") as f:
            f.write(encrypted_access_key + b"\n")
            f.write(encrypted_access_secret + b"\n")
            f.write(encrypted_token + b"\n")
            f.write(encrypted_refresh_token + b"\n")
            f.write(encrypted_user_id + b"\n")
            f.write(encrypted_workspace_id + b"\n")
            f.write(encrypted_workspace_name + b"\n")
            f.write(encrypted_mode + b"\n")

    except Exception as e:
        print("Error saving credentials:", e)


def load_credentials():
    # Load the encryption key
    key = load_key()

    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=SALT,
        iterations=100000,
    )

    # Create a Fernet object with the encryption key
    fernet = Fernet(base64.urlsafe_b64encode(kdf.derive(key)))

    # Load the encrypted credentials from the .credentials file
    try:
        with open(CREDENTIALS_FILE, "rb") as f:
            lines = f.readlines()
            encrypted_access_key = lines[0].strip()
            encrypted_access_secret = lines[1].strip()
            encrypted_token = lines[2].strip()
            encrypted_refresh_token = lines[3].strip()
            encrypted_user_id = lines[4].strip()
            encrypted_workspace_id = lines[5].strip()
            encrypted_workspace_name = lines[6].strip()
            encrypted_mode = lines[7].strip()
    except FileNotFoundError:
        return None, None, None, None, None, None, None, None
    except Exception:
        return None, None, None, None, None, None, None, None

    # Decrypt the credentials
    access_key = (
        fernet.decrypt(encrypted_access_key).decode() if encrypted_access_key else None
    )
    access_secret = (
        fernet.decrypt(encrypted_access_secret).decode()
        if encrypted_access_secret
        else None
    )
    token = fernet.decrypt(encrypted_token).decode() if encrypted_token else None
    refresh_token = (
        fernet.decrypt(encrypted_refresh_token).decode()
        if encrypted_refresh_token
        else None
    )
    user_id = fernet.decrypt(encrypted_user_id).decode() if encrypted_user_id else None
    workspace_id = (
        fernet.decrypt(encrypted_workspace_id).decode()
        if encrypted_workspace_id
        else None
    )
    workspace_name = (
        fernet.decrypt(encrypted_workspace_name).decode()
        if encrypted_workspace_name
        else None
    )
    mode = fernet.decrypt(encrypted_mode).decode() if encrypted_mode else None
    return (
        access_key,
        access_secret,
        token,
        refresh_token,
        user_id,
        workspace_id,
        workspace_name,
        mode,
    )


def select_url(url_dev, url_prod):
    mode = "PROD"
    if keyring is None:
        _, _, _, _, _, _, _, mode = load_credentials()
    else:
        try:
            keyring.get_keyring()
            mode = keyring.get_password("Inferless", "mode")
        except Exception:
            mode = "PROD"
    if mode == "DEV":
        return url_dev
    else:
        return url_prod
